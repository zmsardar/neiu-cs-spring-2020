package problem1;

import javafx.geometry.Point2D;
import javafx.scene.image.PixelWriter;
import javafx.scene.paint.Color;

public class Pixel
{
    private Point2D point;
    private Color color;

    public Pixel(Point2D point, Color color) {

        if(point == null || color == null) {
            throw new NullPointerException("One of the parameters is null");
        }

        this.point = point;
        this.color = color;
    }

    public Point2D getPoint() {
        return this.point;
    }

    public Color getColor() {
        return this.color;
    }

    @Override
    public String toString() {
        String s = "<" + this.point.getX() + ", " + this.point.getY() + ", " + this.color + ">";
        return s;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Pixel)) {
            return false;
        }
        Pixel other = (Pixel) obj;
        return ((this.color.equals(other.color)) && ((this.point.equals(other.point))));
    }

    @Override
    public int hashCode() {
        final int HASH = 31;
        int result = 1;
        result = HASH * result + this.point.hashCode();
        result = HASH * result + this.color.hashCode();
        return result;
    }

    public void draw(PixelWriter writer) {
        writer.setColor((int) point.getX(), (int) point.getY(), color);
    }
}
