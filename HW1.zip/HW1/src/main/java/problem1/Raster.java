package problem1;

import javafx.scene.image.PixelWriter;
import javafx.scene.image.WritableImage;

public class Raster
{
    private Pixel[][] raster;

    public int getRowSize() {
        return raster.length;
    }

    public int getColumnSize() {
        return raster[0].length;
    }

    public Raster(int rows, int columns) {
        if(rows < 1 || columns < 1) {
            throw new IllegalArgumentException("The values for rows and columns need to be 1 or more");
        }
        this.raster = new Pixel[rows][columns];
    }

    @Override
    public String toString() {
        String s = getRowSize() + " rows by " + getColumnSize() + " columns";
        return s;
    }

    @Override
    public boolean equals(Object obj) {
        if(!(obj instanceof Raster)) {
            return false;
        }
        Raster other = (Raster) obj;
        for(int i = 0; i < getRowSize(); i++) {
            for(int j = 0; j < getColumnSize(); j++){
                if(!(this.raster[i][j].equals(other.raster[i][j]))) {
                    return false;
                }
            }
        }
        return ((this.getRowSize() == other.getRowSize()) && this.getColumnSize() == other.getColumnSize());
    }

    public void addPixel(Pixel pixel) {
        int x = (int) pixel.getPoint().getX();
        int y = (int) pixel.getPoint().getY();
        raster[y][x] = pixel;
    }

    public WritableImage drawImage() {
        WritableImage image = new WritableImage(raster[0].length, raster.length);
        PixelWriter writer = image.getPixelWriter();
        for (int i = 0; i < raster.length; i++) {
            for (int j = 0; j < raster[i].length; j++) {
                raster[i][j].draw(writer);
            }
        }
        return image;
    }
}
