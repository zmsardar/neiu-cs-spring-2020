package problem2;

public interface AnalogSignal
{
    float[] getAnalog();
    void setAnalog(float[] data);
    String sendAnalog();
}
