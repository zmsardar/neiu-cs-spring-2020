package problem2;

public class DigitalSignalClient
{
    public static void sendSignal(DigitalSignal signal) {
        System.out.println(signal.sendDigital());
    }
}
