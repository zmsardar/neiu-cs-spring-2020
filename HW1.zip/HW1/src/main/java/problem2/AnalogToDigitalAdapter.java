package problem2;

public class AnalogToDigitalAdapter implements DigitalSignal {

    public static final float DEFAULT_THRESHOLD = 1.0f;

    private AnalogSignal analogSignal;
    private byte[] digitalData;
    private float threshold;

    public AnalogToDigitalAdapter(AnalogSignal analogSignal, float threshold) {
        this.analogSignal = analogSignal;
        this.threshold = threshold;
    }

    public AnalogToDigitalAdapter(AnalogSignal analogSignal) {
        this(analogSignal, DEFAULT_THRESHOLD);
    }

    @Override
    public byte[] getDigital() {
        float[] newFloatArray = this.analogSignal.getAnalog();
        byte[] newByteArray = new byte[newFloatArray.length];

        for(int i = 0; i < newByteArray.length; i++) {
            if(newFloatArray[i] > this.threshold) {
                newByteArray[i] = 1;
            }
            else {
                newByteArray[i] = 0;
            }
        }
        return newByteArray;
    }

    @Override
    public void setDigital(byte[] data) {
        throw new UnsupportedOperationException();
    }

    public void setAnalogData(float[] data) {
        this.analogSignal.setAnalog(data);
    }

    @Override
    public String sendDigital() {
        String s = "[";
        byte[] digArray = getDigital();
        for(int i = 0; i < digArray.length - 1; i++) {
            s += digArray[i] + ", ";
        }
        s += digArray[digArray.length - 1] + "]";
        return s;
    }
}

