package problem2;

public interface DigitalSignal
{
    byte[] getDigital();
    void setDigital(byte[] data);
    String sendDigital();
}
