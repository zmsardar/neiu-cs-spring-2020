package problem2;

public class ClientDemo {

    public static void main(String[] args) {

        float[] newAnalogData = { 1.2f, 0.3f, 0.4f, 1.9f, 2.9f };
        AnalogSignal newAnalogSignal = new FloatAnalogSignal(newAnalogData);
        AnalogToDigitalAdapter analogToDigitalAdapter = new AnalogToDigitalAdapter(newAnalogSignal);
        DigitalSignalClient.sendSignal(analogToDigitalAdapter);

        byte[] newBinaryData = { 1, 0, 0, 1, 1 };
        BinaryDigitalSignal newBinaryDigitalSignal = new BinaryDigitalSignal(newBinaryData);
        System.out.println(newBinaryDigitalSignal.sendDigital());

    }
}
