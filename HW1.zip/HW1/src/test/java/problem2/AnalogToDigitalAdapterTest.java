package problem2;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import problem1.Pixel;

import static org.junit.jupiter.api.Assertions.*;

class AnalogToDigitalAdapterTest {

    private float[] analogData = { 0.2f, 1.4f, 3.12f, 0.9f };
    AnalogSignal analogSignal;

    @BeforeEach
    void initSignal() {
        analogSignal = new FloatAnalogSignal(analogData);
    }

    // FIRST TESTS: Uncomment this comment block after completing the getDigital method
    @Test
    void testGetDigital_shouldConvertDigitalToBinaryWithDefaultThreshold() {
        byte[] binaryData = { 0, 1, 1, 0 };
        AnalogToDigitalAdapter adapter = new AnalogToDigitalAdapter(analogSignal);
        assertArrayEquals(binaryData, adapter.getDigital());
    }

    @Test
    void testGetDigital_shouldConvertDigitalToBinaryWithDifferentThreshold() {
        byte[] binaryData = { 0, 0, 1, 0 };
        AnalogToDigitalAdapter adapter = new AnalogToDigitalAdapter(analogSignal, 2.5f);
        assertArrayEquals(binaryData, adapter.getDigital());
    }

    // SECOND TESTS: Uncomment this comment block after completing the setDigital method
    @Test
    void testSetDigital_shouldThrowUnsupportedExceptionOperation() {
        byte[] binaryData = { 0, 0, 1, 0 };
        AnalogToDigitalAdapter adapter = new AnalogToDigitalAdapter(analogSignal);
        assertThrows(UnsupportedOperationException.class, () -> adapter.setDigital(binaryData));
    }

    // THIRD TESTS: Uncomment this comment block after completing the setAnalogData method
    @Test
    void testSetAnalogData_ShouldSetAnalogDataAndGetCorrectDigital() {
        byte[] binaryData = { 1, 0, 0, 1, 1 };
        AnalogToDigitalAdapter adapter = new AnalogToDigitalAdapter(analogSignal);
        float[] newAnalogData = { 1.2f, 0.3f, 0.4f, 1.9f, 2.9f };
        adapter.setAnalogData(newAnalogData);
        assertArrayEquals(binaryData, adapter.getDigital());
    }

    // FOURTH TESTS: Uncomment this comment block after completing the sendDigital method
    @Test
    void testSendDigital_shouldReturnArrayAsString() {
        byte[] binaryData = { 0, 1, 1, 0 };
        AnalogToDigitalAdapter adapter = new AnalogToDigitalAdapter(analogSignal);
        assertEquals("[0, 1, 1, 0]", adapter.sendDigital());
    }
}