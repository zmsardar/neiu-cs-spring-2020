package problem1;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

class RasterTest {

    private Pixel pixel;
    private Raster raster;

    // Uncomment this first comment block before running any tests!!
    @BeforeEach
    void initAll() {
        pixel = new Pixel(new Point2D(3, 2), Color.THISTLE);
        raster = new Raster(2, 3);
    }

    // Uncomment this second comment block before running any tests!!
    private void addPointsToRaster(Raster raster, boolean random) {
        for (int i = 0; i < raster.getRowSize(); i++) {
            for (int j = 0; j < raster.getColumnSize(); j++) {
                Color c = Color.SILVER;
                if (random)
                    c = Color.color(new Random().nextDouble(),
                            new Random().nextDouble(), new Random().nextDouble());
                raster.addPixel(new Pixel(new Point2D(j, i), c));
            }
        }
    }

    // FIRST TESTS: Uncomment this comment block after completing the constructor
    @Test
    void testPixel_shouldThrowExceptionIfRowSizeIsLessThanOne() {
        assertThrows(IllegalArgumentException.class, () -> raster = new Raster(0, 5));
    }

    @Test
    void testPixel_shouldThrowExceptionIfColumnSizeIsLessThanOne() {
        assertThrows(IllegalArgumentException.class, () -> raster = new Raster(2, -4));
    }

    // SECOND TESTS: Uncomment this comment block after completing the toString method
    @Test
    void testToString_shouldReturnRowAndColumnSizes() {
        Raster raster2 = new Raster(7, 2);
        assertEquals("2 rows by 3 columns", raster.toString());
        assertEquals("7 rows by 2 columns", raster2.toString());
    }

    // THIRD TESTS: Uncomment this comment block after completing the equals method
    @Test
    void testEquals_shouldReturnTrueForRastersWithAllSamePoints() {
        Raster raster2 = new Raster(2, 3);
        addPointsToRaster(raster, false);
        addPointsToRaster(raster2, false);
        assertEquals(true, raster.equals(raster2));
        assertEquals(true, raster2.equals(raster));
    }

    @Test
    void testEquals_shouldReturnFalseForRastersWithDifferentDimensions() {
        Raster raster2 = new Raster(9, 12);
        addPointsToRaster(raster, false);
        addPointsToRaster(raster2, false);
        assertEquals(false, raster.equals(raster2));
    }

    @Test
    void testEquals_shouldReturnFalseForRastersWithDifferentPoints() {
        Raster raster2 = new Raster(2, 3);
        addPointsToRaster(raster, true);
        addPointsToRaster(raster2, true);
        assertEquals(false, raster.equals(raster2));
    }

    @Test
    void testEquals_shouldReturnFalseForRastersWithDifferentPointsAndDimensions() {
        Raster raster2 = new Raster(4, 7);
        addPointsToRaster(raster, true);
        addPointsToRaster(raster2, true);
        assertEquals(false, raster.equals(raster2));
    }
}