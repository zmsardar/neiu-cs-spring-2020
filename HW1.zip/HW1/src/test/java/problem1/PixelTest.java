package problem1;

import javafx.geometry.Point2D;
import javafx.scene.paint.Color;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import problem1.Pixel;

import static org.junit.jupiter.api.Assertions.*;

class PixelTest {

    private Point2D point;
    private Color color;
    private Pixel pixel;

    // Uncomment this first comment block before running any tests!!
    @BeforeEach
    void initAll() {
        point = new Point2D(5, 7);
        color = Color.BLUE;
        pixel = new Pixel(point, color);
    }

    // FIRST TESTS: Uncomment this comment block after completing the constructor
    @Test
    void testPixel_shouldThrowExceptionIfPointIsNull() {
        assertThrows(NullPointerException.class, () -> new Pixel(null, color));
    }

    @Test
    void testPixel_shouldThrowExceptionIfColorIsNull() {
        assertThrows(NullPointerException.class, () -> new Pixel(point, null));
    }

    // SECOND TESTS: Uncomment this comment block after completing the getters
    @Test
    void testGetPoint_shouldReturnInstanceVariablePoint2D() {
        assertEquals(point, pixel.getPoint());
    }

    @Test
    void testGetColor_shouldReturnInstanceVariableColor() {
        assertEquals(color, pixel.getColor());
    }

    // THIRD TESTS: Uncomment this comment block after completing the toString method
    @Test
    void testToString_shouldReturnPointAndColorAsString() {
        assertEquals("<5.0, 7.0, 0x0000ffff>", pixel.toString());
    }

    // FOURTH TESTS: Uncomment this comment block after completing the equals method
    @Test
    void testEquals_shouldReturnTrueForSamePixels() {
        Pixel pixel2 = new Pixel(new Point2D(5, 7), Color.BLUE);
        assertEquals(true, pixel.equals(pixel2));
        assertEquals(true, pixel2.equals(pixel));
    }

    @Test
    void testEquals_shouldReturnFalseForDifferentPixelColors() {
        Pixel pixel2 = new Pixel(new Point2D(5, 7), Color.BISQUE);
        assertEquals(false, pixel.equals(pixel2));
    }

    @Test
    void testEquals_shouldReturnFalseForDifferentPixelPoints() {
        Pixel pixel2 = new Pixel(new Point2D(3, 9), Color.BLUE);
        assertEquals(false, pixel.equals(pixel2));
    }

    @Test
    void testEquals_shouldReturnFalseForDifferentPixelPointAndColor() {
        Pixel pixel2 = new Pixel(new Point2D(3, 9), Color.BISQUE);
        assertEquals(false, pixel.equals(pixel2));
    }

    // FIFTH TESTS: Uncomment this comment block after completing the hashCode method
    @Test
    void testHashCode_shouldReturnSameHashCodeForSameObjects() {
        Pixel pixel2 = new Pixel(new Point2D(5, 7), Color.BLUE);
        assertEquals(pixel.hashCode(), pixel2.hashCode());
    }
}